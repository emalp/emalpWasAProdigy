﻿Imports System.IO
Imports System.Net.Sockets


Public Class Form1
    Dim listener As New TcpListener(44444)
    Dim client As TcpClient
    Dim message As String = ""


    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        
        listener.Stop()

    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listener.Start()
        Timer1.Enabled = True
        Timer1.Start()



    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If listener.Pending = True Then
                message = ""
                client = listener.AcceptTcpClient()
                Dim reader As New StreamReader(client.GetStream())
                While reader.Peek > -1
                    message = message + Convert.ToChar(reader.Read()).ToString
                End While
                Me.Focus()
                TextBox4.Text = TextBox4.Text + message + vbCrLf
                My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Asterisk)

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If TextBox1.Text = "" Then
                MsgBox("Please enter your Name!")
                If TextBox2.Text = "" Then
                    MsgBox("Please enter your IP adress!")
                    If TextBox3.Text = "" Then
                        MsgBox("Please enter your Message!")
                    End If
                End If
            Else
                client = New TcpClient(TextBox2.Text, 44444)
                Dim writer As New StreamWriter(client.GetStream())
                writer.Write(TextBox1.Text + " said: " + TextBox3.Text)
                writer.Flush()
                TextBox3.Text = ("")

            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        If TextBox1.Enabled = False Then TextBox1.Enabled = True Else TextBox1.Enabled = False
        If TextBox2.Enabled = False Then TextBox2.Enabled = True Else TextBox2.Enabled = False

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        OpenFileDialog1.ShowDialog()
        AxWindowsMediaPlayer1.URL = OpenFileDialog1.FileName
    End Sub
End Class
